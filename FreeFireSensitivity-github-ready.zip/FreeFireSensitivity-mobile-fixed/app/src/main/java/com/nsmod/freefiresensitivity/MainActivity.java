package com.nsmod.freefiresensitivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends android.app.Activity {
    private static final String PREFS = "sensitivity_prefs";
    private SharedPreferences prefs;

    private final int blue = Color.rgb(30, 136, 229);
    private final int dark = Color.rgb(11, 18, 32);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        setContentView(buildUi());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(Color.WHITE);

        TextView title = text("FF SENSITIVITY", 26, dark);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, lp(-1, -2));

        TextView sub = text("Preset nhạy cho Free Fire / Free Fire MAX", 15, Color.DKGRAY);
        sub.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(sub, lp(-1, -2));

        LinearLayout presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        presetRow.setGravity(Gravity.CENTER);
        presetRow.setPadding(0, 24, 0, 8);

        Button balanced = button("BALANCED");
        Button high = button("HIGH");
        Button custom = button("CUSTOM");

        presetRow.addView(balanced, lp(0, -2, 1));
        presetRow.addView(high, lp(0, -2, 1));
        presetRow.addView(custom, lp(0, -2, 1));
        root.addView(presetRow, lp(-1, -2));

        LinearLayout sliders = new LinearLayout(this);
        sliders.setOrientation(LinearLayout.VERTICAL);

        addSensitivity(sliders, "General", 0);
        addSensitivity(sliders, "Red Dot", 1);
        addSensitivity(sliders, "2X Scope", 2);
        addSensitivity(sliders, "4X Scope", 3);
        addSensitivity(sliders, "Sniper", 4);

        root.addView(sliders, lp(-1, 0, 1));

        Button save = button("LƯU PRESET");
        save.setOnClickListener(v ->
                Toast.makeText(this, "Đã lưu preset trên thiết bị.", Toast.LENGTH_SHORT).show());
        root.addView(save, lp(-1, -2));

        Button ff = button("MỞ FREE FIRE");
        ff.setOnClickListener(v -> openGame("com.dts.freefireth"));
        root.addView(ff, lp(-1, -2));

        Button ffmax = button("MỞ FREE FIRE MAX");
        ffmax.setOnClickListener(v -> openGame("com.dts.freefiremax"));
        root.addView(ffmax, lp(-1, -2));

        balanced.setOnClickListener(v -> setPreset(70, 65, 60, 50, 40));
        high.setOnClickListener(v -> setPreset(90, 85, 80, 70, 55));
        custom.setOnClickListener(v -> Toast.makeText(this, "Kéo thanh để tự chỉnh.", Toast.LENGTH_SHORT).show());

        return root;
    }

    private void addSensitivity(LinearLayout parent, String label, int index) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, 8, 0, 8);

        TextView value = text(label + ": " + prefs.getInt("s" + index, 70), 15, dark);
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(prefs.getInt("s" + index, 70));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                value.setText(label + ": " + p);
                if (fromUser) prefs.edit().putInt("s" + index, p).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        box.addView(value, lp(-1, -2));
        box.addView(bar, lp(-1, -2));
        parent.addView(box, lp(-1, -2));
    }

    private void setPreset(int a, int b, int c, int d, int e) {
        int[] values = {a, b, c, d, e};
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < values.length; i++) editor.putInt("s" + i, values[i]);
        editor.apply();
        recreate();
    }

    private void openGame(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + packageName)));
        } catch (Exception e) {
            Toast.makeText(this, "Không tìm thấy ứng dụng game.", Toast.LENGTH_SHORT).show();
        }
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(blue);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }
}

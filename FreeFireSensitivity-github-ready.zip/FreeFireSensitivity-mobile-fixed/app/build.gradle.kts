plugins {
    id("com.android.application")
}

android {
    namespace = "com.nsmod.freefiresensitivity"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nsmod.freefiresensitivity"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

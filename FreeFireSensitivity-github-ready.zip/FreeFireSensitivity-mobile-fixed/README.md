# FreeFireSensitivity

Minimal native Android project for saving sensitivity presets and launching Free Fire / Free Fire MAX.

## Fastest build on a phone: GitHub Actions

1. Create an empty GitHub repository.
2. Upload the contents of this project to the repository root (keep `.github/workflows/build-apk.yml`).
3. Commit to the `main` branch.
4. Open **Actions** -> **Build APK**.
5. After the run finishes, open the run and download artifact **FreeFireSensitivity-debug**.
6. Extract the artifact and install `app-debug.apk`.

The workflow installs JDK 17, Android SDK 34, Gradle 8.7, builds `assembleDebug`, and uploads the APK. No Gradle wrapper is required.

## Local build

Open the project in an Android IDE with JDK 17 and Gradle 8.7 support, sync, then run `assembleDebug`.

## Scope

The app stores preset values locally and launches the installed game packages. It does not modify game files, memory, or input behavior.
